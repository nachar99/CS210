#include <iostream>
using namespace std;

/*
Abdulrahman Al-Nachar
9/4/23
CS210- 1-5 Comparing Languages
*/

// this is the main function
int main() {
	cout << "Hello, World!" << endl;
	return 0;
	// this will print Hello, World!
}