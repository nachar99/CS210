# Abdulrahman Al-Nachar , 9/4/23, for the comparing languages assignment 1-5

# this prints Hello, World!
print("Hello, World!")

