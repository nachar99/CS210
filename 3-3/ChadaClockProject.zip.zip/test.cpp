#include <iostream>
#include <string>

using namespace std;

int main() {
    int twentyFourHours = 00;
    cout << twentyFourHours << endl;
    return 0;
}